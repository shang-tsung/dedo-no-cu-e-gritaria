<h3> Teste Fácil Consulta </h3>

<label> 
  <ul>Tecnologias utilizadas para
    marcação e estilização:
    <li>HTML5 </li>
    <li>CSS3 </li>
  </ul>
    </br>
    <ul>
    Linguaguem de programação:
    <li>JavaScript </li>
       </ul>
       </br>
    <ul>
    Framework de JS:
    <li>VUEJS </li>
    </ul>
    <ul>
    Framework de CSS utilizamos:
    <li>Bootstrap </li>
    </ul>
</label>

<h4> Descrição do projeto: </h4></br>
<p> Crie um projeto com VUE no qual faça o cadastro do profissional, selecione a especialidade do mesmo, forma de pagamento e exiba uma página de revisão de cadastro 
</p>


<ul>
  
  Obrigatoriedades do projeto:
  <li>Utilizamos váriaveis com CSS</li>
  <li>Utilizamos um componente para controlar as rotas, com routerlink e router-view</li>
  <li>mascaramento dos inputs com v-mask e gota d'agua placeholder</li>
  <li>O select está com um laço para que o estado selecionado mostre no select da cidade o estado correspondente</li>
  <li>Projeto responsívo</li>
  
</ul>

