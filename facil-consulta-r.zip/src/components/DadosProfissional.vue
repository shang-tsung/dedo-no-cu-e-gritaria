<template>
  <div class="container-sm p-5 row">
    <form class="col-sm-12 col-lg-6">
      <h1 class="mb-4">Sobre o profisional</h1>
      <h5 class="bold mb-4">Dados do profissional</h5>
      <div class="mb-3 col-12">
        <label for="nomeCompleto" class="form-label">Nome completo*</label>
        <input
          type="text"
          class="form-control"
          id="nomeCompleto"
          placeholder="Digite o nome completo"
          v-model="nomeCompleto"
          v-model.="$v.nomeCompleto.$model"
        />
        <div
          class="error"
          v-if="$v.nomeCompleto.$invalid && $v.nomeCompleto.$dirty"
        >
          Nome completo é obrigatório.
        </div>
      </div>
      <div class="mb-3 col-9">
        <label for="cpf" class="form-label">CPF*</label>
        <input
          id="cpf"
          class="form-control"
          type="text"
          placeholder="Digite um CPF"
          v-model.trim="$v.cpf.$model"
          v-mask="'###.###.###-##'"
        />
        <div class="error" v-if="$v.cpf.$invalid && $v.cpf.$dirty">
          CPF é obrigatório.
        </div>
      </div>
      <div class="mb-3 col-9">
        <label for="numero-celular" class="form-label"
          >Número de celular*</label
        >
        <input
          id="numero-celular"
          class="form-control"
          type="text"
          v-model="telefone"
          v-model.trim="$v.telefone.$model"
          v-mask="'(##) # ####-####'"
          placeholder="(00) 0 0000-0000"
        />
        <div class="error" v-if="$v.telefone.$invalid && $v.telefone.$dirty">
          Insira um telefone para contato.
        </div>
      </div>
      <div class="mb-3 row">
        <div class="col">
          <label for="estado" class="form-label">Estado*</label>
          <select
            v-model="estadoSelecionado"
            v-model.trim="$v.estadoSelecionado.$model"
            class="form-select"
            id="estado"
            required
          >
            <option value="" selected disabled>Selecione</option>
            <option
              v-for="(estado, index) in localidades"
              :value="index"
              :key="index"
              :v-model="estadoSelecionado"
            >
              {{ index }}
            </option>
          </select>
          <div
            class="error"
            v-if="$v.estadoSelecionado.$invalid && $v.estadoSelecionado.$dirty"
          >
            Selecione um estado.
          </div>
        </div>

        <div class="col">
          <label for="cidade" class="form-label">Cidade*</label>
          <select
            class="form-select col-6"
            aria-label="Cidade"
            id="cidade"
            v-model="cidadeSelecionada"
            :disabled="!temEstadoSelecionado"
          >
            <option value="" selected disabled>Selecione</option>
            <option
              v-for="(cidade, index) in cidades"
              :key="index"
              :value="cidade"
            >
              {{ cidade }}
            </option>
          </select>
        </div>
      </div>
      <div class="progress-status row g-0">
        <div class="progress mb-3 col-10">
          <div
            class="progress-bar bg-primary w-50"
            role="progressbar"
            aria-valuenow="50"
            aria-valuemin="0"
            aria-valuemax="100"
          ></div>
        </div>
        <span class="col-2 text-end text-primary"> 1 de 2 </span>
      </div>
      <router-link to="/atendimento">
        <button
          type="button"
          class="btn btn-primary rounded-pill mb-3 w-100"
          @click="salvarDados"
        >
          Próximo
        </button>
      </router-link>
      <router-view />
    </form>
    <div class="col-md-6 d-none d-lg-block d-xl-block g-0 row">
      <figure class="figure d-flex h-100 align-items-center">
        <img
          src="../assets/desktop-pagina-1.png"
          class="figure-img img-fluid"
          alt="cadastro profisional"
        />
      </figure>
    </div>
  </div>
</template>

<script>
import { required, minLength } from '@vuelidate/validators'
import useVuelidate from '@vuelidate/core'
import { mapState } from 'vuex'
export default {
  name: 'dados-profissional',
  setup() {
    return {
      $v: useVuelidate(),
    }
  },
  data() {
    return {
      nomeCompleto: '',
      estadoSelecionado: '',
      cidadeSelecionada: '',
      cpf: '',
      telefone: '',
      localidades: {
        Parana: ['londrina', 'Maringa'],
        'Rio Grande do Sul': ['Pelotas', 'Porto Alegre'],
        'Santa Catarina': ['Florianópolis', 'Joinville'],
      },
    }
  },
  methods: {
    salvarDados() {
      this.$store.commit('salvarProfissional', {
        nomeCompleto: this.nomeCompleto,
        estadoSelecionado: this.estadoSelecionado,
        cidadeSelecionada: this.cidadeSelecionada,
        cpf: this.cpf,
        telefone: this.telefone,
      })
    },
  },
  computed: {
    ...mapState([]),
    temEstadoSelecionado: function() {
      return this.estadoSelecionado != '' ? true : false
    },
    cidades: function() {
      return this.localidades[this.estadoSelecionado]
    },
  },
  validations() {
    return {
      nomeCompleto: {
        required,
        minLength: minLength(4),
      },
      cpf: {
        required,
        minLength: minLength(12),
      },
      telefone: {
        required,
        minLength: minLength(11),
      },
      estadoSelecionado: {
        required,
      },
    }
  },
}
</script>

<style>
.error {
  color: var(--danger);
}
.container-sm.card {
  border-top-left-radius: 25px;
  border-top-right-radius: 25px;
  flex-direction: row; /* alterado */
}
@media (min-width: 992px) {
  .container-sm {
    max-width: 936px;
  }
  .container-sm.card {
    border-bottom-left-radius: 25px;
    border-bottom-right-radius: 25px;
  }
}
.card-title {
  font-family: 'Comfortaa', cursive;
}
</style>
