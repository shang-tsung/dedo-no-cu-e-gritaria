<template>
  <div class="container-sm p-5 row">
    <router-link to="/atendimento">
      <span>&lt;</span>
    </router-link>
    <router-view />
    <div class="col-sm-12 col-lg-6">
      <h1 class="mb-4">Revisão do cadastro</h1>
      <div class="dadosConfirmacao">
        <label for="Nome"> Nome completo: </label>
        <p>{{ revisaoCadastro.nomeCompleto }}</p>
        <label for="cpf"> cpf: </label>
        <p>{{ revisaoCadastro.cpf }}</p>
        <label for="tel"> telefone: </label>
        <p>{{ revisaoCadastro.telefone }}</p>
        <label for="state"> Estado </label>
        <p>{{ revisaoCadastro.estadoSelecionado }}</p>
        <label for="especialidade"> Especialidade </label>
        <p>{{ revisaoCadastro.especialidadeSelecionado }}</p>
      </div>
      <div>
        <label for="price"> Preço da consulta </label>
        <p>R${{ revisaoCadastro.precoConsulta }}</p>
      </div>
      <div>
        <label for="payment"> forma de pagamento </label>
        <p v-if="revisaoCadastro.formaPagamento == 'dinheiro'">Dinheiro</p>
        <p v-else-if="revisaoCadastro.formaPagamento == 'pix'">Pix</p>
        <p v-else>
          Cartão de crédito
          <span v-if="revisaoCadastro.parcelamento == 'cartaoCredito'">
            - Parcelamento em {{ revisaoCadastro.parcelamento }} sem juros</span
          >
        </p>
      </div>

      <div class="d-flex justify-content-center">
        <button
          type="button"
          class="btn btn-secondary col-4 rounded-pill mb-3 w-100"
        >
          Cadastrar Profissional
        </button>
      </div>

      <div class="d-flex justify-content-center">
        <router-link to="/">
          <a href="#" class="text-primary">Editar cadastro</a>
        </router-link>
      </div>
    </div>
    <div class="col-lg-6 d-none d-lg-block d-xl-block g-0 row">
      <figure class="figure d-flex h-100 align-items-center">
        <img
          src="../assets/desktop-pagina-3.png"
          class="figure-img img-fluid"
          alt="cadastro profisional"
        />
      </figure>
    </div>
  </div>
</template>

<script>
export default {
  name: 'revisao-cadastro',
  computed: {
    revisaoCadastro() {
      return this.$store.state
    },
  },
}
</script>

<style></style>
