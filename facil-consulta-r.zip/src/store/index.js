import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    nomeCompleto: '',
    estadoSelecionado: '',
    cidadeSelecionada: '',
    cpf: '',
    telefone: '',
    localidades: '',
    formaPagamento: '',
    parcelamento: '',
    precoConsulta: '',
    especialidadeSelecionado: '',
  },
  mutations: {
    salvarProfissional(state, payload) {
      state.nomeCompleto = payload.nomeCompleto
      state.estadoSelecionado = payload.estadoSelecionado
      state.cidadeSelecionada = payload.cidadeSelecionada
      state.cpf = payload.cpf
      state.telefone = payload.telefone
      state.localidades = payload.localidades
    },
    salvarAtendimento(state, payload) {
      state.formaPagamento = payload.formaPagamento
      state.precoConsulta = payload.precoConsulta
      state.especialidadeSelecionado = payload.especialidadeSelecionado
    },
  },
  actions: {},
  modules: {},
})
